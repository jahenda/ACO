package com.jahendamercy.com.views.activities;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import com.google.android.material.navigation.NavigationView;
import com.jahendamercy.com.views.fragments.PayFragment;
import com.jahendamercy.com.R;
import com.jahendamercy.com.views.fragments.AfyaFragment;
import com.jahendamercy.com.views.fragments.CalendarmonthactFragment;
import com.jahendamercy.com.views.fragments.EmergencyFragment;
import com.jahendamercy.com.views.fragments.SabbathhousesupplyFragment;
import com.jahendamercy.com.views.fragments.SabbathhousetextFragment;
import com.jahendamercy.com.views.fragments.SetdevotionFragment;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
    private Object AppCompatActivity;
    private Object Activity;
    private Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();


        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        //add this line to display menu1 when the activity is loaded
        displaySelectedScreen(R.id.nav_sabbathhouse);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.vr_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void displaySelectedScreen(int itemId) {

        //creating fragment object
        Fragment fragment = null;
        String title = getString(R.string.app_name);

        //initializing the fragment object which is selected
        switch (itemId) {
            case R.id.nav_sabbathhousetext:
                Activity = new SabbathhousetextFragment();
                break;
            case R.id.nav_setdevotions:
                AppCompatActivity = new SetdevotionFragment();
                break;
            case R.id.nav_sabbathhousesupplie:
                Activity = new SabbathhousesupplyFragment();
                break;
            case R.id.nav_calendarmonthact:
                Activity = new CalendarmonthactFragment();
                break;
            case R.id.nav_emergencydial:
                Activity = new EmergencyFragment();
                break;
            case R.id.nav_afya:
                Activity = new AfyaFragment();
                break;
            case R.id.phone_in:
                Activity = new Phone();
                break;
            case R.id.nav_payment:
                Activity = new PayFragment();
                break;
            case R.id.nav_logout:
                Activity = new Signout();
                break;
        }

        //replacing the fragment
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.fragment_container, fragment);
            ft.commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        //calling the method displayselectedscreen and passing the id of selected menu
        displaySelectedScreen(item.getItemId());
        //make this method blank
        return true;
    }

}