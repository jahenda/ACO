package com.jahendamercy.com;

public class PrivacyPolicy {
}
